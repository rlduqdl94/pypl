def get_server():
    global server
    global database
    global username
    global password
    server = '10.0.0.2'
    # 데이터 베이스 이름
    database = 'game_calendar'
    # 접속 유저명
    username = 'sa'
    # 접속 유저 패스워드
    password = 'sejoongDB9778@$'
    
    return server

def get_database():
    global server
    global database
    global username
    global password
    server = '10.0.0.2'
    # 데이터 베이스 이름
    database = 'game_calendar'
    # 접속 유저명
    username = 'sa'
    # 접속 유저 패스워드
    password = 'sejoongDB9778@$'
    
    return database
def get_username():
    global server
    global database
    global username
    global password
    server = '10.0.0.2'
    # 데이터 베이스 이름
    database = 'game_calendar'
    # 접속 유저명
    username = 'sa'
    # 접속 유저 패스워드
    password = 'sejoongDB9778@$'
    
    return username

def get_password():
    global server
    global database
    global username
    global password
    server = '10.0.0.2'
    # 데이터 베이스 이름
    database = 'game_calendar'
    # 접속 유저명
    username = 'sa'
    # 접속 유저 패스워드
    password = 'sejoongDB9778@$'
    
    return password